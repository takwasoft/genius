<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExtraChargeRule extends Model
{
    protected $guarded=[];
}
