<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BoostPaymentExtraCharge extends Model
{
    //
}
