<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdditionalField extends Model
{
    protected $guarded=[];
}
