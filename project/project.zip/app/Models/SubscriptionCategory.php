<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubscriptionCategory extends Model
{
    protected $fillable = ['subscription_id','category_id'];
}
