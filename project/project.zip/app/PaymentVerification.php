<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentVerification extends Model
{
    protected $guarded=[];
}
