<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TopAdCategory extends Model
{
    protected $fillable = [
        'id','price','status','duration'
        ];
}
