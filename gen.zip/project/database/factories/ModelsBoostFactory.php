<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Boost::class, function (Faker $faker) {
    return [
        //
    ];
});
