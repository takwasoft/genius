<?php

use Faker\Generator as Faker;

$factory->define(App\Models\BoostCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
