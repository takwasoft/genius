<?php

use Faker\Generator as Faker;

$factory->define(App\Models\BrandCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
