<?php

use Faker\Generator as Faker;

$factory->define(App\Models\UserCategories::class, function (Faker $faker) {
    return [
        //
    ];
});
