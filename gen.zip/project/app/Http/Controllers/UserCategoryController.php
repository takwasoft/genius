<?php

namespace App\Http\Controllers;

use App\Models\UserCategories;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UserCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\UserCategories  $userCategories
     * @return \Illuminate\Http\Response
     */
    public function show(UserCategories $userCategories)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\UserCategories  $userCategories
     * @return \Illuminate\Http\Response
     */
    public function edit(UserCategories $userCategories)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\UserCategories  $userCategories
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserCategories $userCategories)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\UserCategories  $userCategories
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserCategories $userCategories)
    {
        //
    }
}
